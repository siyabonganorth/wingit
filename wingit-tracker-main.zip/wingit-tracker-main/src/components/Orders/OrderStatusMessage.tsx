
import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { OrderStatus } from "@/types";
import { AlertCircle, CheckCircle, Truck } from "lucide-react";

interface OrderStatusMessageProps {
  isOpen: boolean;
  onClose: () => void;
  status: OrderStatus;
  customerName: string;
  orderItems: { name: string; quantity: number }[];
}

const OrderStatusMessage: React.FC<OrderStatusMessageProps> = ({
  isOpen,
  onClose,
  status,
  customerName,
  orderItems,
}) => {
  const getStatusContent = () => {
    const date = new Date();
    const formattedDate = date.toLocaleDateString("en-ZA", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    const formattedTime = date.toLocaleTimeString("en-ZA", {
      hour: "2-digit",
      minute: "2-digit",
    });

    const itemsText = orderItems.map(item => `${item.quantity}x ${item.name}`).join(", ");

    switch (status) {
      case "preparing":
        return {
          title: "Your Order is Being Prepared!",
          icon: <AlertCircle className="h-12 w-12 text-blue-500 mx-auto mb-4" />,
          message: (
            <>
              <p className="mb-4">Hi {customerName},</p>
              <p className="mb-4">
                Great news! We've started preparing your order ({itemsText}).
              </p>
              <p className="mb-4">
                We're working hard to get your delicious food ready. Please hang tight!
              </p>
              <p className="text-sm text-muted-foreground">
                - WingIt Team
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                {formattedDate} at {formattedTime}
              </p>
            </>
          ),
        };
      case "ready":
        return {
          title: "Your Order is Ready!",
          icon: <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />,
          message: (
            <>
              <p className="mb-4">Hi {customerName},</p>
              <p className="mb-4">
                Great news! Your order ({itemsText}) is now ready.
              </p>
              <p className="mb-4">
                If you've opted for delivery, it's on its way to you now. For pickup, your order is ready for collection.
              </p>
              <p className="text-sm text-muted-foreground">
                - WingIt Team
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                {formattedDate} at {formattedTime}
              </p>
            </>
          ),
        };
      case "delivered":
        return {
          title: "Your Order Has Been Delivered!",
          icon: <Truck className="h-12 w-12 text-purple-500 mx-auto mb-4" />,
          message: (
            <>
              <p className="mb-4">Hi {customerName},</p>
              <p className="mb-4">
                Your order ({itemsText}) has been delivered.
              </p>
              <p className="mb-4">
                Thank you for choosing WingIt! We hope you enjoy your meal.
              </p>
              <p className="text-sm text-muted-foreground">
                - WingIt Team
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                {formattedDate} at {formattedTime}
              </p>
            </>
          ),
        };
      default:
        return {
          title: "Order Update",
          icon: null,
          message: <p>Your order status has been updated.</p>,
        };
    }
  };

  const { title, icon, message } = getStatusContent();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">{title}</DialogTitle>
        </DialogHeader>
        <div className="p-4 bg-white rounded-lg border text-center">
          {icon}
          <div className="text-left">{message}</div>
        </div>
        <DialogFooter className="sm:justify-center">
          <Button onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OrderStatusMessage;
