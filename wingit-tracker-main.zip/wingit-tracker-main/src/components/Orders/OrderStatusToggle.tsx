
import React from "react";
import { Button } from "@/components/ui/button";
import { Clock, AlertCircle, CheckCircle, Truck, XCircle } from "lucide-react";
import { OrderStatus } from "@/types";
import { toast } from "sonner";

interface OrderStatusToggleProps {
  currentStatus: OrderStatus;
  onStatusChange: (status: OrderStatus) => void;
  showStatusMessage?: boolean;
}

export const OrderStatusToggle: React.FC<OrderStatusToggleProps> = ({
  currentStatus,
  onStatusChange,
  showStatusMessage = false,
}) => {
  const handleStatusChange = (status: OrderStatus) => {
    onStatusChange(status);
    
    if (showStatusMessage) {
      switch (status) {
        case "preparing":
          toast("Order is now being prepared. The customer has been notified.");
          break;
        case "ready":
          toast("Order is now ready. The customer has been notified.");
          break;
        case "delivered":
          toast("Order has been marked as delivered.");
          break;
      }
    }
  };

  return (
    <div className="flex flex-wrap gap-2 mt-2">
      <Button
        size="sm"
        variant={currentStatus === "pending" ? "default" : "outline"}
        className={
          currentStatus === "pending"
            ? "bg-yellow-500 hover:bg-yellow-600"
            : "text-yellow-500 border-yellow-300 hover:bg-yellow-50"
        }
        onClick={() => handleStatusChange("pending")}
      >
        <Clock className="h-4 w-4 mr-1" />
        Pending
      </Button>
      
      <Button
        size="sm"
        variant={currentStatus === "preparing" ? "default" : "outline"}
        className={
          currentStatus === "preparing"
            ? "bg-blue-500 hover:bg-blue-600"
            : "text-blue-500 border-blue-300 hover:bg-blue-50"
        }
        onClick={() => handleStatusChange("preparing")}
      >
        <AlertCircle className="h-4 w-4 mr-1" />
        Preparing
      </Button>
      
      <Button
        size="sm"
        variant={currentStatus === "ready" ? "default" : "outline"}
        className={
          currentStatus === "ready"
            ? "bg-green-500 hover:bg-green-600"
            : "text-green-500 border-green-300 hover:bg-green-50"
        }
        onClick={() => handleStatusChange("ready")}
      >
        <CheckCircle className="h-4 w-4 mr-1" />
        Ready
      </Button>
      
      <Button
        size="sm"
        variant={currentStatus === "delivered" ? "default" : "outline"}
        className={
          currentStatus === "delivered"
            ? "bg-purple-500 hover:bg-purple-600"
            : "text-purple-500 border-purple-300 hover:bg-purple-50"
        }
        onClick={() => handleStatusChange("delivered")}
      >
        <Truck className="h-4 w-4 mr-1" />
        Delivered
      </Button>
      
      <Button
        size="sm"
        variant={currentStatus === "cancelled" ? "default" : "outline"}
        className={
          currentStatus === "cancelled"
            ? "bg-red-500 hover:bg-red-600"
            : "text-red-500 border-red-300 hover:bg-red-50"
        }
        onClick={() => handleStatusChange("cancelled")}
      >
        <XCircle className="h-4 w-4 mr-1" />
        Cancelled
      </Button>
    </div>
  );
};

export default OrderStatusToggle;
