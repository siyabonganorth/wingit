
import { useAuth } from "@/context/AuthContext";
import Header from "./Header";

export default function PageLayout({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();

  return (
    <div className="flex flex-col min-h-screen">
      {isAuthenticated && <Header />}
      <main className="flex-1 container mx-auto px-3 md:px-4 py-4 md:py-8 overflow-x-hidden">
        {children}
      </main>
      <footer className="bg-wingit-secondary text-white py-4">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} WingIt - Happyplace</p>
        </div>
      </footer>
    </div>
  );
}
