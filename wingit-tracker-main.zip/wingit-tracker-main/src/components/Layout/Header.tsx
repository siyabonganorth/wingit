
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { PlusCircle, LogOut, User } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const location = useLocation();
  const { user, logout } = useAuth();
  
  return (
    <header className="bg-wingit-primary text-wingit-dark shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <img src="/lovable-uploads/6c7911d3-58a7-47a0-8493-e39ac7dc3766.png" alt="WingIt Logo" className="h-12 mr-2 rounded-full" />
            <h1 className="text-2xl font-bold tracking-tight">
              WingIt
            </h1>
          </Link>
        </div>
        
        <nav className="flex items-center space-x-1 md:space-x-4">
          <Link to="/">
            <Button 
              variant={location.pathname === "/" ? "secondary" : "ghost"} 
              className="text-wingit-dark hover:text-wingit-dark hover:bg-wingit-accent"
            >
              Dashboard
            </Button>
          </Link>
          <Link to="/orders">
            <Button 
              variant={location.pathname.includes("/orders") ? "secondary" : "ghost"} 
              className="text-wingit-dark hover:text-wingit-dark hover:bg-wingit-accent"
            >
              Orders
            </Button>
          </Link>
          <Link to="/menu">
            <Button 
              variant={location.pathname.includes("/menu") ? "secondary" : "ghost"} 
              className="text-wingit-dark hover:text-wingit-dark hover:bg-wingit-accent"
            >
              Menu
            </Button>
          </Link>
          <Link to="/inventory">
            <Button 
              variant={location.pathname.includes("/inventory") ? "secondary" : "ghost"} 
              className="text-wingit-dark hover:text-wingit-dark hover:bg-wingit-accent"
            >
              Inventory
            </Button>
          </Link>
          <Link to="/quotes">
            <Button 
              variant={location.pathname.includes("/quotes") ? "secondary" : "ghost"} 
              className="text-wingit-dark hover:text-wingit-dark hover:bg-wingit-accent"
            >
              Quotes
            </Button>
          </Link>
          
          {location.pathname === "/orders" && (
            <Link to="/orders/new">
              <Button className="ml-2 bg-wingit-secondary hover:bg-purple-500 text-white">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Order
              </Button>
            </Link>
          )}
          
          {location.pathname === "/menu" && (
            <Link to="/menu/new">
              <Button className="ml-2 bg-wingit-secondary hover:bg-purple-500 text-white">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Item
              </Button>
            </Link>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{user?.name}</p>
                  <p className="text-xs leading-none text-muted-foreground">
                    {user?.email}
                  </p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="cursor-pointer">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </nav>
      </div>
    </header>
  );
}
