
import React, { createContext, useContext, useState, useEffect } from 'react';
import { MenuItem, Order } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'sonner';

interface AppContextType {
  menuItems: MenuItem[];
  orders: Order[];
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (item: MenuItem) => void;
  deleteMenuItem: (id: string) => void;
  addOrder: (order: Omit<Order, 'id' | 'createdAt'>) => void;
  updateOrderStatus: (id: string, status: Order['status']) => void;
  updateOrder: (order: Order) => void;
  deleteOrder: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Sample menu items with fixed pricing (R55 for wings)
const defaultMenuItems: MenuItem[] = [
  {
    id: '1',
    name: 'Classic Buffalo Wings',
    price: 55, // R55 fixed price
    category: 'Wings',
    description: 'Traditional spicy buffalo wings',
    cost: 30.50,
  },
  {
    id: '2',
    name: 'BBQ Wings',
    price: 55, // R55 fixed price
    category: 'Wings',
    description: 'Sweet and tangy BBQ wings',
    cost: 30.50,
  },
  {
    id: '3',
    name: 'Garlic Parmesan Wings',
    price: 55, // R55 fixed price
    category: 'Wings',
    description: 'Savory garlic parmesan wings',
    cost: 32.00,
  },
  {
    id: '4',
    name: 'French Fries',
    price: 25,
    category: 'Sides',
    description: 'Crispy golden french fries',
    cost: 10.20,
  },
  {
    id: '5',
    name: 'Soda',
    price: 12,
    category: 'Beverages',
    description: 'Refreshing carbonated drink',
    cost: 5.75,
  },
];

// Sample orders for demonstration with fixed delivery fee of R15
const defaultOrders: Order[] = [
  {
    id: '1',
    customerName: 'John Smith',
    items: [
      {
        menuItemId: '1',
        name: 'Classic Buffalo Wings',
        price: 55,
        quantity: 2,
      },
      {
        menuItemId: '4',
        name: 'French Fries',
        price: 25,
        quantity: 1,
      },
    ],
    status: 'preparing',
    total: 135, // (55 * 2) + 25
    createdAt: new Date(Date.now() - 45 * 60000).toISOString(), // 45 minutes ago
    phoneNumber: '555-123-4567',
    source: 'Walk-in',
    deliveryFee: 0, // Walk-in has no delivery fee
  },
  {
    id: '2',
    customerName: 'Jane Doe',
    items: [
      {
        menuItemId: '2',
        name: 'BBQ Wings',
        price: 55,
        quantity: 1,
      },
      {
        menuItemId: '5',
        name: 'Soda',
        price: 12,
        quantity: 2,
      },
    ],
    status: 'pending',
    total: 94, // 55 + (12 * 2) + 15 delivery fee
    createdAt: new Date(Date.now() - 10 * 60000).toISOString(), // 10 minutes ago
    phoneNumber: '555-987-6543',
    source: 'WhatsApp',
    deliveryFee: 15, // R15 delivery fee
  },
];

export const AppProvider = ({ children }: { children: React.ReactNode }) => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => {
    const saved = localStorage.getItem('wingit-menu-items');
    return saved ? JSON.parse(saved) : defaultMenuItems;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('wingit-orders');
    return saved ? JSON.parse(saved) : defaultOrders;
  });

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('wingit-menu-items', JSON.stringify(menuItems));
  }, [menuItems]);

  useEffect(() => {
    localStorage.setItem('wingit-orders', JSON.stringify(orders));
  }, [orders]);

  const addMenuItem = (item: Omit<MenuItem, 'id'>) => {
    // For wing items, enforce the R55 price
    let price = item.price;
    if (item.category.toLowerCase().includes('wing')) {
      price = 55;
    }
    
    const newItem = { ...item, id: uuidv4(), price };
    setMenuItems((prev) => [...prev, newItem]);
    toast.success("Menu item added successfully");
  };

  const updateMenuItem = (item: MenuItem) => {
    // For wing items, enforce the R55 price
    let updatedItem = { ...item };
    if (item.category.toLowerCase().includes('wing')) {
      updatedItem.price = 55;
    }
    
    setMenuItems((prev) =>
      prev.map((menuItem) => (menuItem.id === item.id ? updatedItem : menuItem))
    );
    toast.success("Menu item updated successfully");
  };

  const deleteMenuItem = (id: string) => {
    setMenuItems((prev) => prev.filter((item) => item.id !== id));
    toast.success("Menu item deleted successfully");
  };

  const addOrder = (order: Omit<Order, 'id' | 'createdAt'>) => {
    // Add delivery fee if not already present
    let total = order.total;
    let deliveryFee = order.deliveryFee;

    if (order.source !== 'Walk-in' && deliveryFee === undefined) {
      deliveryFee = 15; // R15 default delivery fee
      total += deliveryFee;
    }

    const newOrder = {
      ...order,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      deliveryFee,
      total
    };
    
    setOrders((prev) => [...prev, newOrder]);
    toast.success("Order added successfully");
  };

  const updateOrderStatus = (id: string, status: Order['status']) => {
    setOrders((prev) =>
      prev.map((order) =>
        order.id === id ? { ...order, status } : order
      )
    );
    toast.success(`Order status updated to ${status}`);
  };

  const updateOrder = (updatedOrder: Order) => {
    // Ensure delivery fee is applied correctly
    let order = { ...updatedOrder };
    
    if (order.source !== 'Walk-in' && order.deliveryFee === undefined) {
      order.deliveryFee = 15; // R15 default delivery fee
      order.total += 15;
    }
    
    setOrders((prev) =>
      prev.map((order) =>
        order.id === updatedOrder.id ? updatedOrder : order
      )
    );
    toast.success("Order updated successfully");
  };

  const deleteOrder = (id: string) => {
    setOrders((prev) => prev.filter((order) => order.id !== id));
    toast.success("Order deleted successfully");
  };

  return (
    <AppContext.Provider
      value={{
        menuItems,
        orders,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        addOrder,
        updateOrderStatus,
        updateOrder,
        deleteOrder,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
