
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { PlusCircle, Save, Trash } from "lucide-react";
import { toast } from "sonner";

// Define the type for inventory items
interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  unitCost: number;
  totalCost: number;
  lastRestocked: string;
}

const InventoryPage = () => {
  // Sample inventory data
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(() => {
    const saved = localStorage.getItem('wingit-inventory');
    return saved ? JSON.parse(saved) : [
      {
        id: "1",
        name: "Chicken Wings",
        quantity: 100,
        unit: "kg",
        unitCost: 89.99,
        totalCost: 8999.00,
        lastRestocked: new Date().toISOString(),
      },
      {
        id: "2",
        name: "BBQ Sauce",
        quantity: 20,
        unit: "bottles",
        unitCost: 45.50,
        totalCost: 910.00,
        lastRestocked: new Date().toISOString(),
      },
      {
        id: "3",
        name: "Hot Sauce",
        quantity: 15,
        unit: "bottles",
        unitCost: 52.99,
        totalCost: 794.85,
        lastRestocked: new Date().toISOString(),
      }
    ];
  });

  const [newItem, setNewItem] = useState({
    name: "",
    quantity: 0,
    unit: "",
    unitCost: 0,
  });

  // Calculate total inventory value
  const totalInventoryValue = inventoryItems.reduce(
    (total, item) => total + item.totalCost,
    0
  );

  const handleAddItem = () => {
    if (!newItem.name || !newItem.unit || newItem.quantity <= 0 || newItem.unitCost <= 0) {
      toast.error("Please fill in all fields with valid values");
      return;
    }

    const totalCost = newItem.quantity * newItem.unitCost;
    
    const item: InventoryItem = {
      id: Date.now().toString(),
      name: newItem.name,
      quantity: newItem.quantity,
      unit: newItem.unit,
      unitCost: newItem.unitCost,
      totalCost: totalCost,
      lastRestocked: new Date().toISOString(),
    };

    const updatedItems = [...inventoryItems, item];
    setInventoryItems(updatedItems);
    localStorage.setItem('wingit-inventory', JSON.stringify(updatedItems));
    
    // Reset form
    setNewItem({
      name: "",
      quantity: 0,
      unit: "",
      unitCost: 0,
    });
    
    toast.success("Item added to inventory");
  };

  const handleDeleteItem = (id: string) => {
    const updatedItems = inventoryItems.filter(item => item.id !== id);
    setInventoryItems(updatedItems);
    localStorage.setItem('wingit-inventory', JSON.stringify(updatedItems));
    toast.success("Item removed from inventory");
  };

  const handleRestockItem = (id: string) => {
    // In a real app, you would open a modal to enter the restock quantity
    const newQuantity = prompt("Enter new stock quantity:");
    if (newQuantity === null) return;
    
    const parsedQuantity = parseInt(newQuantity, 10);
    if (isNaN(parsedQuantity) || parsedQuantity <= 0) {
      toast.error("Please enter a valid quantity");
      return;
    }

    const updatedItems = inventoryItems.map(item => {
      if (item.id === id) {
        const totalCost = parsedQuantity * item.unitCost;
        return {
          ...item,
          quantity: parsedQuantity,
          totalCost: totalCost,
          lastRestocked: new Date().toISOString()
        };
      }
      return item;
    });

    setInventoryItems(updatedItems);
    localStorage.setItem('wingit-inventory', JSON.stringify(updatedItems));
    toast.success("Stock updated successfully");
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-wingit-dark">Inventory Management</h1>
        <Card className="p-4 bg-wingit-accent">
          <p className="text-sm font-medium">Total Inventory Value</p>
          <p className="text-2xl font-bold">R {totalInventoryValue.toFixed(2)}</p>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New Inventory Item</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <Label htmlFor="item-name">Item Name</Label>
              <Input
                id="item-name"
                value={newItem.name}
                onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                placeholder="Chicken Wings"
              />
            </div>
            <div>
              <Label htmlFor="quantity">Quantity</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                value={newItem.quantity || ""}
                onChange={(e) => setNewItem({ ...newItem, quantity: parseInt(e.target.value) || 0 })}
                placeholder="100"
              />
            </div>
            <div>
              <Label htmlFor="unit">Unit</Label>
              <Input
                id="unit"
                value={newItem.unit}
                onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                placeholder="kg"
              />
            </div>
            <div>
              <Label htmlFor="unitCost">Unit Cost (R)</Label>
              <Input
                id="unitCost"
                type="number"
                min="0"
                step="0.01"
                value={newItem.unitCost || ""}
                onChange={(e) => setNewItem({ ...newItem, unitCost: parseFloat(e.target.value) || 0 })}
                placeholder="89.99"
              />
            </div>
            <div className="flex items-end">
              <Button onClick={handleAddItem} className="w-full bg-wingit-primary hover:bg-wingit-secondary">
                <PlusCircle className="mr-2 h-4 w-4" />
                Add Item
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Current Inventory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead className="text-right">Unit Cost</TableHead>
                  <TableHead className="text-right">Total Cost</TableHead>
                  <TableHead className="text-right">Last Restocked</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventoryItems.length > 0 ? (
                  inventoryItems.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell>{item.unit}</TableCell>
                      <TableCell className="text-right">R {item.unitCost.toFixed(2)}</TableCell>
                      <TableCell className="text-right">R {item.totalCost.toFixed(2)}</TableCell>
                      <TableCell className="text-right">
                        {new Date(item.lastRestocked).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleRestockItem(item.id)}
                          >
                            <Save className="h-4 w-4" />
                            <span className="sr-only">Restock</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteItem(item.id)}
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No inventory items found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InventoryPage;
