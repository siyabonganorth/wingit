
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAppContext } from "@/context/AppContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { OrderItem, Order, OrderStatus } from "@/types";
import { 
  PlusCircle, 
  MinusCircle, 
  Trash, 
  Save,
  ArrowLeft
} from "lucide-react";
import { toast } from "sonner";

const OrderForm = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { menuItems, orders, addOrder, updateOrder } = useAppContext();
  const isEditing = orderId !== undefined;

  const emptyOrder: Omit<Order, "id" | "createdAt"> = {
    customerName: "",
    items: [],
    status: "pending",
    total: 0,
    phoneNumber: "",
    source: "Walk-in",
    notes: "",
  };

  const [formData, setFormData] = useState<Omit<Order, "id" | "createdAt">>(emptyOrder);
  const [newItemId, setNewItemId] = useState("");
  const [newItemQuantity, setNewItemQuantity] = useState(1);
  const [newItemNote, setNewItemNote] = useState("");

  useEffect(() => {
    if (isEditing) {
      const order = orders.find((o) => o.id === orderId);
      if (order) {
        // Create a copy of the order without id and createdAt for the form
        const { id, createdAt, ...orderData } = order;
        setFormData(orderData);
      } else {
        toast.error("Order not found");
        navigate("/orders");
      }
    }
  }, [isEditing, orderId, orders, navigate]);

  const calculateTotal = (items: OrderItem[]) => {
    return items.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleStatusChange = (status: OrderStatus) => {
    setFormData({ ...formData, status });
  };

  const handleSourceChange = (source: "Walk-in" | "WhatsApp" | "Phone") => {
    setFormData({ ...formData, source });
  };

  const handleAddItem = () => {
    if (!newItemId) {
      toast.error("Please select an item");
      return;
    }

    const menuItem = menuItems.find((item) => item.id === newItemId);
    if (!menuItem) {
      toast.error("Item not found");
      return;
    }

    // Check if item already exists in order
    const existingItemIndex = formData.items.findIndex(
      (item) => item.menuItemId === newItemId
    );

    let updatedItems;
    if (existingItemIndex >= 0) {
      // Update existing item
      updatedItems = [...formData.items];
      updatedItems[existingItemIndex] = {
        ...updatedItems[existingItemIndex],
        quantity: updatedItems[existingItemIndex].quantity + newItemQuantity,
        notes: newItemNote || updatedItems[existingItemIndex].notes,
      };
    } else {
      // Add new item
      const newItem: OrderItem = {
        menuItemId: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: newItemQuantity,
        notes: newItemNote,
      };
      updatedItems = [...formData.items, newItem];
    }

    const updatedTotal = calculateTotal(updatedItems);

    setFormData({
      ...formData,
      items: updatedItems,
      total: updatedTotal,
    });

    // Reset the form fields
    setNewItemId("");
    setNewItemQuantity(1);
    setNewItemNote("");
  };

  const handleRemoveItem = (index: number) => {
    const updatedItems = formData.items.filter((_, i) => i !== index);
    const updatedTotal = calculateTotal(updatedItems);

    setFormData({
      ...formData,
      items: updatedItems,
      total: updatedTotal,
    });
  };

  const handleQuantityChange = (index: number, change: number) => {
    const updatedItems = [...formData.items];
    const newQuantity = Math.max(1, updatedItems[index].quantity + change);
    updatedItems[index] = { ...updatedItems[index], quantity: newQuantity };

    const updatedTotal = calculateTotal(updatedItems);

    setFormData({
      ...formData,
      items: updatedItems,
      total: updatedTotal,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.customerName) {
      toast.error("Customer name is required");
      return;
    }

    if (formData.items.length === 0) {
      toast.error("Order must have at least one item");
      return;
    }

    try {
      if (isEditing && orderId) {
        const orderToUpdate = orders.find((o) => o.id === orderId);
        if (orderToUpdate) {
          updateOrder({
            ...orderToUpdate,
            ...formData,
          });
        }
      } else {
        addOrder(formData);
      }
      navigate("/orders");
    } catch (error) {
      toast.error("Error saving order");
      console.error(error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigate("/orders")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Orders
          </Button>
          <h1 className="text-2xl md:text-3xl font-bold text-wingit-dark">
            {isEditing ? "Edit Order" : "New Order"}
          </h1>
        </div>
        <Button 
          className="bg-wingit-primary hover:bg-wingit-secondary" 
          onClick={handleSubmit}
        >
          <Save className="h-4 w-4 mr-2" />
          Save Order
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-5">
                    <Label htmlFor="newItemId">Menu Item</Label>
                    <Select
                      value={newItemId}
                      onValueChange={setNewItemId}
                    >
                      <SelectTrigger id="newItemId">
                        <SelectValue placeholder="Select an item" />
                      </SelectTrigger>
                      <SelectContent>
                        {menuItems.map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {item.name} - R{item.price.toFixed(2)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-2">
                    <Label htmlFor="newItemQuantity">Quantity</Label>
                    <Input
                      id="newItemQuantity"
                      type="number"
                      min="1"
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(parseInt(e.target.value) || 1)}
                    />
                  </div>
                  <div className="md:col-span-3">
                    <Label htmlFor="newItemNote">Note (Optional)</Label>
                    <Input
                      id="newItemNote"
                      value={newItemNote}
                      onChange={(e) => setNewItemNote(e.target.value)}
                      placeholder="Special instructions"
                    />
                  </div>
                  <div className="md:col-span-2 flex items-end">
                    <Button
                      onClick={handleAddItem}
                      className="w-full"
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border mt-4 overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead className="text-center">Quantity</TableHead>
                        <TableHead className="text-right">Price</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {formData.items.length > 0 ? (
                        formData.items.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell>
                              <div>
                                <div className="font-medium">{item.name}</div>
                                {item.notes && (
                                  <div className="text-sm text-muted-foreground">
                                    Note: {item.notes}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange(index, -1)}
                                >
                                  <MinusCircle className="h-4 w-4" />
                                </Button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange(index, 1)}
                                >
                                  <PlusCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              R{item.price.toFixed(2)}
                            </TableCell>
                            <TableCell className="text-right">
                              R{(item.price * item.quantity).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveItem(index)}
                              >
                                <Trash className="h-4 w-4" />
                                <span className="sr-only">Remove</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="h-24 text-center">
                            No items added to this order yet.
                          </TableCell>
                        </TableRow>
                      )}
                      {formData.items.length > 0 && (
                        <TableRow className="border-t-2">
                          <TableCell colSpan={3} className="text-right font-bold">
                            Total:
                          </TableCell>
                          <TableCell className="text-right font-bold">
                            R{formData.total.toFixed(2)}
                          </TableCell>
                          <TableCell></TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Customer Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="customerName">Name</Label>
                  <Input
                    id="customerName"
                    name="customerName"
                    value={formData.customerName}
                    onChange={handleInputChange}
                    placeholder="Customer name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <Input
                    id="phoneNumber"
                    name="phoneNumber"
                    value={formData.phoneNumber || ""}
                    onChange={handleInputChange}
                    placeholder="Phone number"
                  />
                </div>

                <div>
                  <Label htmlFor="source">Order Source</Label>
                  <Select
                    value={formData.source || "Walk-in"}
                    onValueChange={(value) => handleSourceChange(value as "Walk-in" | "WhatsApp" | "Phone")}
                  >
                    <SelectTrigger id="source">
                      <SelectValue placeholder="Select source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Walk-in">Walk-in</SelectItem>
                      <SelectItem value="WhatsApp">WhatsApp</SelectItem>
                      <SelectItem value="Phone">Phone</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="status">Order Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleStatusChange(value as OrderStatus)}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="preparing">Preparing</SelectItem>
                      <SelectItem value="ready">Ready</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="notes">Order Notes</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes || ""}
                    onChange={handleInputChange}
                    placeholder="Special instructions or notes about this order"
                    className="min-h-[100px]"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default OrderForm;
