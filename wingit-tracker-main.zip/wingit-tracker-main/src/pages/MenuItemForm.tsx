
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAppContext } from "@/context/AppContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";
import { MenuItem } from "@/types";

const MenuItemForm = () => {
  const { itemId } = useParams<{ itemId: string }>();
  const navigate = useNavigate();
  const { menuItems, addMenuItem, updateMenuItem } = useAppContext();
  const isEditing = itemId !== undefined;

  const [formData, setFormData] = useState<Omit<MenuItem, "id">>({
    name: "",
    price: 0,
    category: "",
    description: "",
    cost: 0,
  });

  useEffect(() => {
    if (isEditing) {
      const item = menuItems.find((i) => i.id === itemId);
      if (item) {
        // Create a copy of the item without id for the form
        const { id, ...itemData } = item;
        setFormData(itemData);
      } else {
        toast.error("Menu item not found");
        navigate("/menu");
      }
    }
  }, [isEditing, itemId, menuItems, navigate]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    
    // For numeric fields, convert to number or set to zero if empty
    if (name === "price" || name === "cost") {
      const numberValue = value === "" ? 0 : parseFloat(value);
      setFormData({ ...formData, [name]: numberValue });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const validateForm = () => {
    if (!formData.name) {
      toast.error("Item name is required");
      return false;
    }
    if (!formData.category) {
      toast.error("Category is required");
      return false;
    }
    if (formData.price <= 0) {
      toast.error("Price must be greater than zero");
      return false;
    }
    // Cost can be zero, but not negative
    if (formData.cost < 0) {
      toast.error("Cost cannot be negative");
      return false;
    }
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    try {
      if (isEditing && itemId) {
        updateMenuItem({
          id: itemId,
          ...formData,
        });
      } else {
        addMenuItem(formData);
      }
      navigate("/menu");
    } catch (error) {
      toast.error("Error saving menu item");
      console.error(error);
    }
  };

  // Calculate profit and profit margin
  const profit = formData.price - (formData.cost || 0);
  const profitMargin = formData.price > 0 ? (profit / formData.price) * 100 : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigate("/menu")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Menu
          </Button>
          <h1 className="text-3xl font-bold text-wingit-dark">
            {isEditing ? "Edit Menu Item" : "New Menu Item"}
          </h1>
        </div>
        <Button 
          className="bg-wingit-secondary hover:bg-purple-500 text-white" 
          onClick={handleSubmit}
        >
          <Save className="h-4 w-4 mr-2" />
          Save Item
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Item Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Item Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Item name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    placeholder="e.g. Wings, Sides, Beverages"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description || ""}
                    onChange={handleInputChange}
                    placeholder="Item description"
                    className="min-h-[100px]"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="price">Price (R)</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={handleInputChange}
                    placeholder="0.00"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="cost">Cost (R) (Optional)</Label>
                  <Input
                    id="cost"
                    name="cost"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.cost || ""}
                    onChange={handleInputChange}
                    placeholder="0.00"
                  />
                </div>

                {formData.price > 0 && formData.cost !== undefined && formData.cost >= 0 && (
                  <div className="p-4 bg-wingit-accent rounded-lg">
                    <h3 className="font-medium mb-2">Profit Analysis</h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div>Profit:</div>
                      <div className="text-right">R{profit.toFixed(2)}</div>
                      <div>Margin:</div>
                      <div className="text-right">{profitMargin.toFixed(1)}%</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default MenuItemForm;
