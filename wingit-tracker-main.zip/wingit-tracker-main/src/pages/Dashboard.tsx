
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAppContext } from "@/context/AppContext";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { OrderStatus, Order } from "@/types";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { format, subDays, isAfter } from "date-fns";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF0000'];
const STATUS_COLORS: Record<OrderStatus, string> = {
  pending: '#FFBB28',
  preparing: '#0088FE',
  ready: '#00C49F',
  delivered: '#FF8042',
  cancelled: '#FF0000',
};

const Dashboard = () => {
  const { orders, menuItems } = useAppContext();
  const [timeRange, setTimeRange] = useState<7 | 30 | 90>(7);
  
  // Filter orders by time range
  const startDate = subDays(new Date(), timeRange);
  const filteredOrders = orders.filter(order => 
    isAfter(new Date(order.createdAt), startDate)
  );
  
  // Calculate daily revenue
  const dailyRevenueData = Array.from({ length: timeRange }, (_, i) => {
    const date = subDays(new Date(), i);
    const dateStr = format(date, 'MMM dd');
    
    const dailyOrders = filteredOrders.filter(order => 
      format(new Date(order.createdAt), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
    
    const revenue = dailyOrders.reduce((sum, order) => sum + order.total, 0);
    
    return {
      date: dateStr,
      revenue,
    };
  }).reverse();
  
  // Calculate order status counts
  const orderStatusData = ['pending', 'preparing', 'ready', 'delivered', 'cancelled'].map(status => {
    const count = filteredOrders.filter(order => order.status === status).length;
    return { status, count };
  }).filter(item => item.count > 0);
  
  // Calculate top selling items
  const itemSales: Record<string, { id: string, name: string, quantity: number, revenue: number }> = {};
  filteredOrders.forEach(order => {
    order.items.forEach(item => {
      if (!itemSales[item.menuItemId]) {
        itemSales[item.menuItemId] = {
          id: item.menuItemId,
          name: item.name,
          quantity: 0,
          revenue: 0
        };
      }
      itemSales[item.menuItemId].quantity += item.quantity;
      itemSales[item.menuItemId].revenue += item.price * item.quantity;
    });
  });
  
  const topSellingItems = Object.values(itemSales)
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);
  
  // Calculate total revenue, orders, and profit
  const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.total, 0);
  const totalOrders = filteredOrders.length;
  
  // Calculate profit (revenue - cost)
  let totalCost = 0;
  filteredOrders.forEach(order => {
    order.items.forEach(item => {
      const menuItem = menuItems.find(mi => mi.id === item.menuItemId);
      if (menuItem && menuItem.cost) {
        totalCost += menuItem.cost * item.quantity;
      }
    });
  });
  
  const totalProfit = totalRevenue - totalCost;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-wingit-dark">Dashboard</h1>
        <div className="flex space-x-2">
          <Button
            variant={timeRange === 7 ? "default" : "outline"}
            onClick={() => setTimeRange(7)}
            className={timeRange === 7 ? "bg-wingit-secondary hover:bg-purple-500 text-white" : ""}
          >
            Last 7 Days
          </Button>
          <Button
            variant={timeRange === 30 ? "default" : "outline"}
            onClick={() => setTimeRange(30)}
            className={timeRange === 30 ? "bg-wingit-secondary hover:bg-purple-500 text-white" : ""}
          >
            Last 30 Days
          </Button>
          <Button
            variant={timeRange === 90 ? "default" : "outline"}
            onClick={() => setTimeRange(90)}
            className={timeRange === 90 ? "bg-wingit-secondary hover:bg-purple-500 text-white" : ""}
          >
            Last 90 Days
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Revenue</CardTitle>
            <CardDescription>Last {timeRange} days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Orders</CardTitle>
            <CardDescription>Last {timeRange} days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOrders}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total Profit</CardTitle>
            <CardDescription>Last {timeRange} days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{totalProfit.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Daily Revenue</CardTitle>
            <CardDescription>
              Revenue trend over the last {timeRange} days
            </CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={dailyRevenueData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => [`R${Number(value).toFixed(2)}`, 'Revenue']}
                />
                <Bar dataKey="revenue" fill="#9b87f5" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Order Status</CardTitle>
            <CardDescription>
              Current order status distribution
            </CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={orderStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                  nameKey="status"
                >
                  {orderStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={STATUS_COLORS[entry.status as OrderStatus]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [value, 'Orders']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Items</CardTitle>
            <CardDescription>
              Most popular menu items by quantity sold
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topSellingItems.map((item, index) => (
                <div key={item.id} className="flex justify-between items-center">
                  <div>
                    <div className="font-medium">{index + 1}. {item.name}</div>
                    <div className="text-sm text-muted-foreground">
                      R{item.revenue.toFixed(2)} total revenue
                    </div>
                  </div>
                  <div className="text-xl font-semibold">{item.quantity}</div>
                </div>
              ))}
              
              {topSellingItems.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">
                  No sales data available for this period
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
