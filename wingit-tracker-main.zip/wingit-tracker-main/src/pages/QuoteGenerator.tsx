
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, MinusCircle, FileDown, FilePlus, Trash, Eye, Copy } from "lucide-react";
import { useAppContext } from "@/context/AppContext";
import { toast } from "sonner";

interface QuoteItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
}

const QuoteGenerator = () => {
  const { menuItems } = useAppContext();
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [deliveryFee, setDeliveryFee] = useState(15); // Default delivery fee is R15
  const [items, setItems] = useState<QuoteItem[]>([]);
  const [newItemId, setNewItemId] = useState("");
  const [newItemQuantity, setNewItemQuantity] = useState(1);
  const [previewOpen, setPreviewOpen] = useState(false);

  // Calculate subtotal
  const subtotal = items.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  // Calculate total with delivery fee
  const total = subtotal + deliveryFee;

  const handleAddItem = () => {
    if (!newItemId) {
      toast.error("Please select an item");
      return;
    }

    const menuItem = menuItems.find((item) => item.id === newItemId);
    if (!menuItem) {
      toast.error("Item not found");
      return;
    }

    // Check if item already exists in order
    const existingItemIndex = items.findIndex(
      (item) => item.menuItemId === newItemId
    );

    let updatedItems;
    if (existingItemIndex >= 0) {
      // Update existing item
      updatedItems = [...items];
      updatedItems[existingItemIndex] = {
        ...updatedItems[existingItemIndex],
        quantity: updatedItems[existingItemIndex].quantity + newItemQuantity,
      };
    } else {
      // Add new item
      const newItem: QuoteItem = {
        menuItemId: menuItem.id,
        name: menuItem.name,
        price: menuItem.price,
        quantity: newItemQuantity,
      };
      updatedItems = [...items, newItem];
    }

    setItems(updatedItems);
    setNewItemId("");
    setNewItemQuantity(1);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleQuantityChange = (index: number, change: number) => {
    const updatedItems = [...items];
    const newQuantity = Math.max(1, updatedItems[index].quantity + change);
    updatedItems[index] = { ...updatedItems[index], quantity: newQuantity };
    setItems(updatedItems);
  };

  const validateForm = () => {
    if (!customerName) {
      toast.error("Customer name is required");
      return false;
    }
    if (items.length === 0) {
      toast.error("At least one item is required");
      return false;
    }
    return true;
  };

  const handleGenerateQuote = () => {
    if (!validateForm()) return;

    // In a real app, you would save the quote to the database
    // and potentially generate a PDF
    toast.success("Quote generated successfully");

    // For now, we'll just generate a simple text version
    const quoteText = generateQuoteText();
    
    // Create a downloadable text file
    const element = document.createElement("a");
    const file = new Blob([quoteText], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `WingIt_Quote_${customerName.replace(/\s+/g, '_')}_${new Date().toLocaleDateString().replace(/\//g, '-')}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleSaveQuote = () => {
    if (!validateForm()) return;

    // In a real app, you would save the quote to the database
    // For now, we'll just use localStorage
    const quote = {
      id: Date.now().toString(),
      customerName,
      customerEmail,
      customerPhone,
      items,
      subtotal,
      deliveryFee,
      total,
      notes,
      createdAt: new Date().toISOString(),
    };

    // Get existing quotes from localStorage
    const existingQuotes = JSON.parse(localStorage.getItem('wingit-quotes') || '[]');
    const updatedQuotes = [...existingQuotes, quote];
    
    // Save to localStorage
    localStorage.setItem('wingit-quotes', JSON.stringify(updatedQuotes));
    
    toast.success("Quote saved successfully");
    
    // Reset form
    setCustomerName("");
    setCustomerEmail("");
    setCustomerPhone("");
    setItems([]);
    setNotes("");
  };

  const generateQuoteText = () => {
    return `
QUOTE FOR: ${customerName}
${customerEmail ? `EMAIL: ${customerEmail}` : ''}
${customerPhone ? `PHONE: ${customerPhone}` : ''}
DATE: ${new Date().toLocaleDateString()}

ITEMS:
${items.map(item => `- ${item.name} x ${item.quantity}: R${(item.price * item.quantity).toFixed(2)}`).join('\n')}

SUBTOTAL: R${subtotal.toFixed(2)}
DELIVERY FEE: R${deliveryFee.toFixed(2)}
TOTAL: R${total.toFixed(2)}

${notes ? `NOTES: ${notes}` : ''}

Thank you for considering WingIt!
This quote is valid for 7 days.
    `;
  };

  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(generateQuoteText())
      .then(() => toast.success("Quote copied to clipboard"))
      .catch(() => toast.error("Failed to copy to clipboard"));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-2">
        <h1 className="text-2xl md:text-3xl font-bold text-wingit-dark">Quote Generator</h1>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline" 
            onClick={() => setPreviewOpen(true)}
          >
            <Eye className="mr-2 h-4 w-4" />
            Preview
          </Button>
          <Button
            className="bg-wingit-secondary hover:bg-purple-500 text-white"
            onClick={handleSaveQuote}
          >
            <FilePlus className="mr-2 h-4 w-4" />
            Save Quote
          </Button>
          <Button
            variant="outline" 
            onClick={handleGenerateQuote}
          >
            <FileDown className="mr-2 h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Quote Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  <div className="md:col-span-7">
                    <Label htmlFor="newItemId">Menu Item</Label>
                    <Select
                      value={newItemId}
                      onValueChange={setNewItemId}
                    >
                      <SelectTrigger id="newItemId">
                        <SelectValue placeholder="Select an item" />
                      </SelectTrigger>
                      <SelectContent>
                        {menuItems.map((item) => (
                          <SelectItem key={item.id} value={item.id}>
                            {item.name} - R{item.price.toFixed(2)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="md:col-span-3">
                    <Label htmlFor="newItemQuantity">Quantity</Label>
                    <Input
                      id="newItemQuantity"
                      type="number"
                      min="1"
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(parseInt(e.target.value) || 1)}
                    />
                  </div>
                  <div className="md:col-span-2 flex items-end">
                    <Button
                      onClick={handleAddItem}
                      className="w-full bg-wingit-secondary hover:bg-purple-500 text-white"
                    >
                      <PlusCircle className="h-4 w-4 mr-2" />
                      Add
                    </Button>
                  </div>
                </div>

                <div className="rounded-md border mt-4 overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead className="text-center">Quantity</TableHead>
                        <TableHead className="text-right">Price</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.length > 0 ? (
                        items.map((item, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell className="text-center">
                              <div className="flex items-center justify-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange(index, -1)}
                                >
                                  <MinusCircle className="h-4 w-4" />
                                </Button>
                                <span className="w-8 text-center">{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleQuantityChange(index, 1)}
                                >
                                  <PlusCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              R{item.price.toFixed(2)}
                            </TableCell>
                            <TableCell className="text-right">
                              R{(item.price * item.quantity).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveItem(index)}
                              >
                                <Trash className="h-4 w-4" />
                                <span className="sr-only">Remove</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={5} className="h-24 text-center">
                            No items added to this quote yet.
                          </TableCell>
                        </TableRow>
                      )}
                      {items.length > 0 && (
                        <>
                          <TableRow>
                            <TableCell colSpan={3} className="text-right font-medium">
                              Subtotal:
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              R{subtotal.toFixed(2)}
                            </TableCell>
                            <TableCell></TableCell>
                          </TableRow>
                          <TableRow>
                            <TableCell colSpan={3} className="text-right font-medium">
                              Delivery Fee:
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              R{deliveryFee.toFixed(2)}
                            </TableCell>
                            <TableCell></TableCell>
                          </TableRow>
                          <TableRow className="border-t-2">
                            <TableCell colSpan={3} className="text-right font-bold">
                              Total:
                            </TableCell>
                            <TableCell className="text-right font-bold">
                              R{total.toFixed(2)}
                            </TableCell>
                            <TableCell></TableCell>
                          </TableRow>
                        </>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Customer Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="customerName">Name</Label>
                  <Input
                    id="customerName"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Customer name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="customerEmail">Email</Label>
                  <Input
                    id="customerEmail"
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="customer@example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="customerPhone">Phone Number</Label>
                  <Input
                    id="customerPhone"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="Phone number"
                  />
                </div>

                <div>
                  <Label htmlFor="deliveryFee">Delivery Fee (R)</Label>
                  <Input
                    id="deliveryFee"
                    type="number"
                    min="0"
                    step="1"
                    value={deliveryFee}
                    onChange={(e) => setDeliveryFee(Number(e.target.value))}
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Additional notes or special instructions"
                    className="min-h-[100px]"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quote Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Quote Preview</DialogTitle>
          </DialogHeader>
          <div className="bg-white p-6 rounded-lg border">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-2xl font-bold text-wingit-dark">WingIt</h2>
                <p className="text-sm text-muted-foreground">By Happyplace</p>
              </div>
              <div className="text-right">
                <p className="font-bold">QUOTE</p>
                <p>{new Date().toLocaleDateString()}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground mb-1">From</h3>
                <p className="font-medium">WingIt</p>
                <p>123 Wing Street</p>
                <p>Cape Town, South Africa</p>
                <p>Phone: 021-555-1234</p>
                <p>Email: info@wingitnow.com</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground mb-1">To</h3>
                <p className="font-medium">{customerName || "[Customer Name]"}</p>
                {customerEmail && <p>Email: {customerEmail}</p>}
                {customerPhone && <p>Phone: {customerPhone}</p>}
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Order Items</h3>
              <div className="border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead className="text-center">Qty</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {items.length > 0 ? (
                      items.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>{item.name}</TableCell>
                          <TableCell className="text-center">{item.quantity}</TableCell>
                          <TableCell className="text-right">R{item.price.toFixed(2)}</TableCell>
                          <TableCell className="text-right">R{(item.price * item.quantity).toFixed(2)}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4">
                          No items added
                        </TableCell>
                      </TableRow>
                    )}
                    <TableRow>
                      <TableCell colSpan={3} className="text-right font-medium">
                        Subtotal:
                      </TableCell>
                      <TableCell className="text-right">
                        R{subtotal.toFixed(2)}
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell colSpan={3} className="text-right font-medium">
                        Delivery Fee:
                      </TableCell>
                      <TableCell className="text-right">
                        R{deliveryFee.toFixed(2)}
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-t-2">
                      <TableCell colSpan={3} className="text-right font-bold">
                        Total:
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        R{total.toFixed(2)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>

            {notes && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Notes</h3>
                <p className="p-3 bg-gray-50 rounded-md border">{notes}</p>
              </div>
            )}

            <div className="text-center text-sm text-muted-foreground mt-8">
              <p>Thank you for considering WingIt! This quote is valid for 7 days.</p>
              <p className="mt-1">For any questions, please contact us at 021-555-1234 or info@wingitnow.com</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={handleCopyToClipboard}>
              <Copy className="h-4 w-4 mr-2" />
              Copy to Clipboard
            </Button>
            <Button onClick={handleGenerateQuote}>
              <FileDown className="h-4 w-4 mr-2" />
              Download Quote
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default QuoteGenerator;
