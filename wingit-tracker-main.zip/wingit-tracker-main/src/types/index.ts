
export interface MenuItem {
  id: string;
  name: string;
  price: number; // Now in Rands
  category: string;
  description?: string;
  cost?: number; // Now in Rands
}

export interface Order {
  id: string;
  customerName: string;
  items: OrderItem[];
  status: OrderStatus;
  total: number; // Now in Rands
  createdAt: string;
  notes?: string;
  phoneNumber?: string;
  source?: 'Walk-in' | 'WhatsApp' | 'Phone';
  deliveryFee?: number; // Added delivery fee - R15 default
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number; // Now in Rands
  quantity: number;
  notes?: string;
}

export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';

export interface Quote {
  id: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  items: QuoteItem[];
  subtotal: number; // Now in Rands
  deliveryFee: number; // Now in Rands - R15 default
  total: number; // Now in Rands
  notes?: string;
  createdAt: string;
}

export interface QuoteItem {
  menuItemId: string;
  name: string;
  price: number; // Now in Rands
  quantity: number;
}

export interface InventoryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  unitCost: number; // Now in Rands
  totalCost: number; // Now in Rands
  lastRestocked: string;
}
