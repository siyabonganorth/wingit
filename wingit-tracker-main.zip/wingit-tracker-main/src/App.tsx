
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "@/context/AppContext";
import { AuthProvider } from "@/context/AuthContext";
import PageLayout from "@/components/Layout/PageLayout";
import ProtectedRoute from "@/components/Auth/ProtectedRoute";
import Dashboard from "./pages/Dashboard";
import OrdersPage from "./pages/OrdersPage";
import OrderForm from "./pages/OrderForm";
import MenuPage from "./pages/MenuPage";
import MenuItemForm from "./pages/MenuItemForm";
import NotFound from "./pages/NotFound";
import LoginPage from "./pages/LoginPage";
import InventoryPage from "./pages/InventoryPage";
import QuoteGenerator from "./pages/QuoteGenerator";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <AppProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <Dashboard />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              
              {/* Order Routes */}
              <Route
                path="/orders"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <OrdersPage />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/orders/new"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <OrderForm />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/orders/edit/:orderId"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <OrderForm />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              
              {/* Menu Routes */}
              <Route
                path="/menu"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <MenuPage />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/menu/new"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <MenuItemForm />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              <Route
                path="/menu/edit/:itemId"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <MenuItemForm />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              
              {/* Inventory Routes */}
              <Route
                path="/inventory"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <InventoryPage />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              
              {/* Quote Generator */}
              <Route
                path="/quotes"
                element={
                  <ProtectedRoute>
                    <PageLayout>
                      <QuoteGenerator />
                    </PageLayout>
                  </ProtectedRoute>
                }
              />
              
              {/* Catch-all route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AppProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
